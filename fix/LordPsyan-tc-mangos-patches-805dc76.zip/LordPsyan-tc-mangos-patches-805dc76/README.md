tc-mangos-patches
=================

Various patches for TrinityCore and MaNGOS. Patches work with various client patch versions from 2.4.3 to 4.3.4

Patches in seperate folders. Labeled by core and client patch version.