/*
Navicat MySQL Data Transfer

Source Server         : trinity
Source Server Version : 50140
Source Host           : localhost:3306
Source Database       : world

Target Server Type    : MYSQL
Target Server Version : 50140
File Encoding         : 65001

Date: 2012-05-25 23:50:31
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `playercreateinfo_item`
-- ----------------------------
DROP TABLE IF EXISTS `playercreateinfo_item`;
CREATE TABLE `playercreateinfo_item` (
  `race` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `class` tinyint(3) unsigned NOT NULL DEFAULT '0',
  `itemid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `amount` tinyint(3) NOT NULL DEFAULT '1',
  KEY `playercreateinfo_race_class_index` (`race`,`class`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of playercreateinfo_item
-- ----------------------------
INSERT INTO playercreateinfo_item VALUES ('1', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('2', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('3', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('4', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('5', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('6', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('7', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('8', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('9', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('10', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('11', '6', '40582', '-1');
INSERT INTO playercreateinfo_item VALUES ('10', '1', '20915', '1');
INSERT INTO playercreateinfo_item VALUES ('10', '1', '20918', '1');
INSERT INTO playercreateinfo_item VALUES ('10', '1', '20919', '1');
INSERT INTO playercreateinfo_item VALUES ('10', '1', '23346', '1');
